package com.example.counsel.service;

import com.example.counsel.entity.User;
import com.example.counsel.repository.UserRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService {

    private final UserRepository userRepository;

    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    // 모든 사용자 조회
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    // 학번으로 사용자 조회
    public User getUserByStudentNumber(String studentNumber) {
        return userRepository.findById(studentNumber)
                .orElseThrow(() -> new IllegalArgumentException("사용자를 찾을 수 없습니다. 학번: " + studentNumber));
    }

    // 사용자 저장
    public User saveUser(User user) {
        return userRepository.save(user);
    }

    // 학번으로 사용자 삭제
    public void deleteUser(String studentNumber) {
        userRepository.deleteById(studentNumber);
    }
}
