//package com.example.counsel.entity;
//
//import jakarta.persistence.*;
//import lombok.Getter;
//import lombok.Setter;
//
//@Entity
//@Getter
//@Setter
//public class BoardInfo {
//
//    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    private Long id; // 게시판 ID (BB_NO)
//
//    @Column(length = 100, nullable = false)
//    private String name; // 게시판 이름 (BB_NM)
//}
