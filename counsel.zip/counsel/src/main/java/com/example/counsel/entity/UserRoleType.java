package com.example.counsel.entity;

import lombok.Getter;

@Getter
public enum UserRoleType {

    ADMIN("관리자"),
    USER("유저"),
    COUNSELOR("상담사"),
    STUDENT("학생");

    private String description;

    UserRoleType(String description) {
        this.description = description;
    }
}
