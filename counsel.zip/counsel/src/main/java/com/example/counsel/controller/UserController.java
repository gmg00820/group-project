package com.example.counsel.controller;

import com.example.counsel.entity.User;
import com.example.counsel.service.UserService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/users")
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    // 모든 사용자 조회
    @GetMapping
    public ResponseEntity<List<User>> getAllUsers() {
        return ResponseEntity.ok(userService.getAllUsers());
    }

    // 특정 사용자 조회 (학번 기준)
    @GetMapping("/{studentNumber}")
    public ResponseEntity<User> getUserByStudentNumber(@PathVariable String studentNumber) {
        return ResponseEntity.ok(userService.getUserByStudentNumber(studentNumber));
    }

    // 사용자 등록
    @PostMapping
    public ResponseEntity<User> createUser(@RequestBody User user) {
        return ResponseEntity.ok(userService.saveUser(user));
    }

    // 사용자 수정 (학번 기준)
    @PutMapping("/{studentNumber}")
    public ResponseEntity<User> updateUser(@PathVariable String studentNumber, @RequestBody User user) {
        user.setStudentNumber(studentNumber);
        return ResponseEntity.ok(userService.saveUser(user));
    }

    // 사용자 삭제 (학번 기준)
    @DeleteMapping("/{studentNumber}")
    public ResponseEntity<Void> deleteUser(@PathVariable String studentNumber) {
        userService.deleteUser(studentNumber);
        return ResponseEntity.noContent().build();
    }
}
