package com.example.counsel.service;

import com.example.counsel.dto.JoinDTO;
import com.example.counsel.entity.UserLoginEntity;
import com.example.counsel.entity.UserRoleType;
import com.example.counsel.repository.UserLoginRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class JoinService {

    @Autowired
    private UserLoginRepository userLoginRepository;

    @Autowired
    private PasswordEncoder bCryptPasswordEncoder; // PasswordEncoder 타입으로 변경

    public void joinProcess(JoinDTO joinDTO) {
        UserLoginEntity user = new UserLoginEntity();
        user.setUsername(joinDTO.getUsername());
        user.setPassword(bCryptPasswordEncoder.encode(joinDTO.getPassword())); // 비밀번호 암호화
        user.setEmail(joinDTO.getEmail());
        user.setName(joinDTO.getName());
        user.setPhone(joinDTO.getPhone());
        user.setRole(UserRoleType.valueOf("ROLE_USER"));
        userLoginRepository.save(user);
    }
}
