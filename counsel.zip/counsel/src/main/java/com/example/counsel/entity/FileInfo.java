package com.example.counsel.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
public class FileInfo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long fileNo;               // 파일 번호 (FILE_NO)

    private Integer seqNo;             // 일련번호 (SEQ_NO)

    @Column(length = 100, nullable = false)
    private String uuid;               // UUID

    @Column(length = 200, nullable = false)
    private String orgFileNm;          // 원본 파일명 (ORG_FILE_NM)

    @Column(length = 200, nullable = false)
    private String filePath;           // 파일 경로 (FILE_PATH)
}
