package com.example.counsel.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.List;

@Entity
@Getter
@Setter
public class ProgramApplication {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long prgrmNo;             // 프로그램 번호 (PRGRM_NO)

    @Column(length = 100, nullable = false)
    private String prgrmNm;           // 프로그램명 (PRGRM_NM)

    @Column(nullable = false)
    private Integer planNope;         // 참가 가능 인원 (PLAN_NOPE)

    @Column(nullable = false)
    private LocalDateTime dscsnRegYmd; // 프로그램 진행 날짜 (DSCSN_REG_YMD)

    @Column(length = 100, nullable = false)
    private String eduPlcNm;          // 진행 장소 (EDU_PLC_NM)

    @Column(nullable = false)
    private LocalDateTime ddlnCrtrYmd; // 마감일 (DDLN_CRTR_YMD)

    // 파일 정보와의 관계 (Many-to-One)
    @ManyToOne
    @JoinColumn(name = "file_no") // 파일 번호 외래키 (FILE_NO)
    private FileInfo fileInfo;

    // 프로그램 신청 현황과의 관계 (One-to-Many)
    @OneToMany(mappedBy = "programApplication", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<ProgramProgress> programProgressList;
}
