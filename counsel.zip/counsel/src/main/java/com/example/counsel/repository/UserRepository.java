package com.example.counsel.repository;

import com.example.counsel.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, String> {
    // 학번을 기본 키로 관리
}
