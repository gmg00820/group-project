package com.example.counsel.service;

import com.example.counsel.dto.CustomOAuth2User;
import com.example.counsel.dto.GoogleResponse;
import com.example.counsel.dto.NaverResponse;
import com.example.counsel.dto.OAuth2Response;
import com.example.counsel.entity.UserLoginEntity;
import com.example.counsel.entity.UserRoleType;
import com.example.counsel.repository.UserLoginRepository;
import org.springframework.security.oauth2.client.userinfo.DefaultOAuth2UserService;
import org.springframework.security.oauth2.client.userinfo.OAuth2UserRequest;
import org.springframework.security.oauth2.core.OAuth2AuthenticationException;
import org.springframework.security.oauth2.core.user.OAuth2User;
import org.springframework.stereotype.Service;

@Service
public class CustomOAuth2UserService extends DefaultOAuth2UserService {
    //DefaultOAuth2UserService OAuth2UserService의 구현체


    private final UserLoginRepository userLoginRepository;

    public CustomOAuth2UserService(UserLoginRepository userLoginRepository) {

        this.userLoginRepository = userLoginRepository;
    }

    @Override
    public OAuth2User loadUser(OAuth2UserRequest userRequest) throws OAuth2AuthenticationException {

        OAuth2User oAuth2User = super.loadUser(userRequest);
        System.out.println(oAuth2User.getAttributes());

        String registrationId = userRequest.getClientRegistration().getRegistrationId();
        OAuth2Response oAuth2Response = null;
        if (registrationId.equals("naver")) {

            oAuth2Response = new NaverResponse(oAuth2User.getAttributes());
        } else if (registrationId.equals("google")) {

            oAuth2Response = new GoogleResponse(oAuth2User.getAttributes());
        } else {

            return null;
        }

        String username = oAuth2Response.getProvider()+" " + oAuth2Response.getProviderId();

        UserLoginEntity existData = userLoginRepository.findByUsername(username);

        String role = null;
        if (existData == null) {

            UserLoginEntity userLoginEntity = new UserLoginEntity();

            userLoginEntity.setUsername(username);
            userLoginEntity.setEmail(oAuth2Response.getProviderId());
            userLoginEntity.setRole(UserRoleType.valueOf("USER"));

            userLoginRepository.save(userLoginEntity);

        }
        else {

            role = String.valueOf(existData.getRole());

            existData.setEmail(oAuth2Response.getEmail());

            userLoginRepository.save(existData);
        }



        return new CustomOAuth2User(oAuth2Response, role);
    }
}