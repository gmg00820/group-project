package com.example.counsel.dto;

import com.example.counsel.entity.UserLoginEntity;
import com.example.counsel.entity.UserRoleType;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.ArrayList;
import java.util.Collection;

public class CustomUserDetails implements UserDetails {

    private final UserLoginEntity userLoginEntity;

    public CustomUserDetails(UserLoginEntity userLoginEntity) {

        this.userLoginEntity = userLoginEntity;
    }


    @Override
    public Collection<? extends GrantedAuthority> getAuthorities() {

        Collection<GrantedAuthority> collection = new ArrayList<>();

        collection.add(new GrantedAuthority() {

            @Override
            public String getAuthority() {

                return UserRoleType.USER.name();
            }
        });

        return collection;
    }

    @Override
    public String getPassword() {
        return userLoginEntity.getPassword();
    }

    @Override
    public String getUsername() {
        return userLoginEntity.getUsername();
    }


    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

    @Override
    public boolean isEnabled() {
        return true;
    }
}