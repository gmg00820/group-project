package com.example.counsel.repository;

import com.example.counsel.entity.UserLoginEntity;
import org.springframework.data.jpa.repository.JpaRepository;


public interface UserLoginRepository extends JpaRepository<UserLoginEntity, Integer> {

    boolean existsByUsername(String username);


    UserLoginEntity findByUsername(String username);

    UserLoginEntity findByEmail(String email);
}
