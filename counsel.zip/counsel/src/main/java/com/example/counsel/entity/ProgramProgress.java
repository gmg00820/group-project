package com.example.counsel.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
public class ProgramProgress {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;                  // 고유 ID

    @ManyToOne
    @JoinColumn(name = "prgrm_no")    // 프로그램 번호 외래키 (PRGRM_NO)
    private ProgramApplication programApplication;

    @Column(length = 10, nullable = false)
    private String empNo;             // 교직원 번호 (EMP_NO)

    @Column(length = 10, nullable = false)
    private String stdntNo;           // 학생 번호 (STDNT_NO)

    @Column(length = 100, nullable = false)
    private String aprvYn;            // 승인 상태 (APRV_YN)

    @Column(nullable = false)
    private Integer rating;           // 프로그램 평점 (RATING)

    @Column(length = 1, nullable = false)
    private String applyYn;           // 신청 여부 (APPLY_YN)

    @Column(length = 1, nullable = false)
    private String engageYn;          // 참여 여부 (ENGAGE_YN)
}
