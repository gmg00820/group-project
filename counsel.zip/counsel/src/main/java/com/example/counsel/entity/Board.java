//package com.example.counsel.entity;
//
//import jakarta.persistence.*;
//import lombok.Getter;
//import lombok.Setter;
//
//import java.time.LocalDateTime;
//
//@Entity
//@Getter
//@Setter
//public class Board {
//
//    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    private Long id; // 게시글 ID (PST_ID)
//
//    @ManyToOne(fetch = FetchType.LAZY)
//    @JoinColumn(name = "BB_NO") // 게시판 번호 (BB_NO)
//    private BoardInfo board; // 게시판 정보 (BB_INFO와 연관)
//
//    @Column(length = 100, nullable = false)
//    private String title; // 게시글 제목 (PST_TTL)
//
//    @Lob
//    private String content; // 게시글 내용 (PST_CN)
//
//    @Column(length = 50, nullable = false)
//    private String username; // 작성자 이름 (WRT_NM)
//
//    private LocalDateTime createdAt; // 작성일시 (PST_WRT_DT)
//
//    private LocalDateTime modifiedAt; // 수정일시 (PST_MDFCN_DT)
//
//    @Column
//    private Integer viewCount; // 조회수 (INQ_CNT)
//
//    @Column(length = 20)
//    private String status; // 상태 (STTS)
//}
