//package com.example.counsel.dto;
//
//import com.example.counsel.entity.Board;
//import lombok.AllArgsConstructor;
//import lombok.Getter;
//import lombok.NoArgsConstructor;
//
//import java.time.LocalDateTime;
//
//@NoArgsConstructor
//@AllArgsConstructor
//@Getter
//public class BoardListResponseDTO {
//
//    private Long postId;             // 게시글 ID (PST_ID)
//    private String boardName;        // 게시판 이름 (BB_NM)
//    private String title;            // 게시글 제목 (PST_TTL)
//    private String writerName;       // 작성자명 (WRT_NM)
//    private LocalDateTime createdAt; // 작성일시 (PST_WRT_DT)
//    private LocalDateTime modifiedAt; // 수정일시 (PST_MDFCN_DT)
//    private Integer viewCount;       // 조회수 (INQ_CNT)
//    private String status;           // 상태 (STTS)
//
//    // Entity -> DTO 변환
//    public BoardListResponseDTO(Board board) {
//        if (board == null) {
//            throw new IllegalArgumentException("Board entity는 null이 될 수 없습니다.");
//        }
//        this.postId = board.getId();              // 게시글 ID
//        this.boardName = board.getBoard().getName(); // 게시판 이름 (연관된 게시판 엔티티에서 가져옴)
//        this.title = board.getTitle();           // 게시글 제목
//        this.writerName = board.getUsername();   // 작성자명
//        this.createdAt = board.getCreatedAt();   // 작성일시
//        this.modifiedAt = board.getModifiedAt(); // 수정일시
//        this.viewCount = board.getViewCount();   // 조회수
//        this.status = board.getStatus();         // 상태
//    }
//}
