//package com.example.counsel.service;
//
//import com.example.counsel.dto.BoardRequestDTO;
//import com.example.counsel.dto.BoardListResponseDTO;
//import com.example.counsel.dto.BoardResponseDTO;
//import com.example.counsel.entity.Board;
//import com.example.counsel.repository.BoardRepository;
//import lombok.AllArgsConstructor;
//import org.springframework.security.core.context.SecurityContextHolder;
//import org.springframework.stereotype.Service;
//
//import jakarta.transaction.Transactional;
//import java.util.ArrayList;
//import java.util.List;
//import java.util.NoSuchElementException;
//
//@Service
//@AllArgsConstructor
//public class BoardService {
//
//    private final BoardRepository boardRepository;
//
//
//    // 권한 확인
//    public boolean isAccess(String username){
//        //현재 로그인 되어 있는 유저의 username
//        String sessionUsername = SecurityContextHolder.getContext().getAuthentication().getName();
//        // 현재 로그인 되어있는 유저의 Role
//        String sessionRole = SecurityContextHolder.getContext().getAuthentication().getAuthorities().toString();
//
//        if ("ADMIN".equals(sessionRole)) {
//            return true;
//        }
//
//        if (username.equals(sessionUsername)){
//            return true;
//        }
//        return false;
//    }
//
//    // 업데이트 메서드
//    public Long update(Long id, BoardRequestDTO requestDTO) {
//        // ID로 Board 찾기
//        Board board = boardRepository.findById(id)
//                .orElseThrow(() -> new NoSuchElementException("id: " + id +"인 게시글은 없습니다"));
//
//        // 권한 확인
//        if (!isAccess(board.getUsername())) {
//            throw new SecurityException("권한이 없습니다.");
//        }
//        // 요청된 데이터로 엔티티 업데이트
//        board.update(requestDTO);
//
//        // 엔티티 저장
//        boardRepository.save(board);
//
//        return board.getId();
//    }
//    //삭제 메서드
//    public Long delete(Long id) {
//        Board board = boardRepository.findById(id)
//                .orElseThrow(() -> new NoSuchElementException("id: " + id +"인 게시글은 없습니다"));
//        boardRepository.delete(board);
//        return id;
//    }
//
//    // 글 생성
//    public BoardResponseDTO createBoard(BoardRequestDTO requestDTO) {
//
//        Board board = new Board();                 // 1. Board -> Entity로 변환
//        boardRepository.save(board);               // 2. DB에 저장
//        return new BoardResponseDTO(board);        // 3. Entity -> ResponseDTO 변환 후 리턴
//
//    }
//
//    // 모든 글 가져오기
//    public List<BoardListResponseDTO> findAllBoard() {
//        try{
//            List<Board> boardList = boardRepository.findAll();
//
//            List<BoardListResponseDTO> responseDtoList = new ArrayList<>();
//
//            for (Board board : boardList) {
//                responseDtoList.add(
//                        new BoardListResponseDTO(board)
//                );
//            }
//            return responseDtoList;
//        } catch (Exception e) {
////            throw new DBEmptyDataException("a");
//        }
//        return null;
//    }
//
//    // 글 하나 가져오기
//    public BoardResponseDTO findOneBoard(Long id) {
//        Board board = boardRepository.findById(id).orElseThrow(
//                () -> new IllegalArgumentException("조회 실패")
//        );
//        return new BoardResponseDTO(board);
//    }
//
//    // 글 수정
//    @Transactional
//    public Long updateBoard(Long id, BoardRequestDTO requestDTO) {
//        Board board = boardRepository.findById(id).orElseThrow(
//                () -> new IllegalArgumentException("해당 아이디가 존재하지 않습니다.")
//        );
//        board.update(requestDTO);
//        return board.getId();
//    }
//
//    // 삭제
//    @Transactional
//    public Long deleteBoard(Long id) {
//        Board board = boardRepository.findById(id)
//                .orElseThrow(() -> new NoSuchElementException("id: " + id +"인 게시글은 없습니다"));
//
//        // 권한 확인
//        if (!isAccess(board.getUsername())) {
//            throw new SecurityException("권한이 없습니다.");
//        }
//        boardRepository.deleteById(id);
//        return id;
//    }
//}
//
