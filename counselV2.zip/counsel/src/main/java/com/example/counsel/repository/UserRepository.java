package com.example.counsel.repository;

import com.example.counsel.entity.User;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User, String> {

    //(studentNumber) 학번 으로 사용자 존재 여부 확인 == 중복확인
    boolean existsByStudentNumber(@NotBlank @Size(max = 10, message = "학번은 최대 10자리까지 입력 가능합니다.") String studentNumber);
    // 학번을 기본 키로 관리
}
