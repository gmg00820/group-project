package com.example.counsel.repository;

import com.example.counsel.entity.Counselor;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CounselorRepository extends JpaRepository<Counselor, String> {
    // 기본적으로 findById, deleteById 등 제공
}
