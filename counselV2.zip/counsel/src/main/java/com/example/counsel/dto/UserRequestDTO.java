package com.example.counsel.dto;

import com.example.counsel.entity.UserRoleType;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class UserRequestDTO {

    @NotBlank
    @Size(max = 10, message = "학번은 최대 10자리까지 입력 가능합니다.")
    private String studentNumber; // 학번

    @NotBlank
    @Size(max = 100, message = "이름은 최대 100자리까지 입력 가능합니다.")
    private String name; // 이름

    @Size(max = 10, message = "성별은 최대 10자리까지 입력 가능합니다.")
    private String gender; // 성별

    @Email(message = "유효한 이메일 형식을 입력해야 합니다.")
    @Size(max = 320, message = "이메일은 최대 320자리까지 입력 가능합니다.")
    private String email; // 이메일

    @Size(max = 15, message = "휴대전화 번호는 최대 15자리까지 입력 가능합니다.")
    private String mobilePhone; // 휴대전화

    @Size(max = 5, message = "우편번호는 최대 5자리까지 입력 가능합니다.")
    private String zipCode; // 우편번호

    @Size(max = 200, message = "주소는 최대 200자리까지 입력 가능합니다.")
    private String address; // 주소

    @Size(max = 200, message = "상세 주소는 최대 200자리까지 입력 가능합니다.")
    private String detailedAddress; // 상세 주소

    private UserRoleType role; // 사용자 역할
}
