package com.example.counsel.service;

import com.example.counsel.dto.UserRequestDTO;
import com.example.counsel.entity.User;
import com.example.counsel.entity.UserRoleType;
import com.example.counsel.repository.UserRepository;
import jakarta.transaction.Transactional;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    public UserService(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Transactional
    public void createOneUser(UserRequestDTO dto) {

        // 동일한 studentNumber가 있는지 확인
        if (userRepository.existsByStudentNumber(dto.getStudentNumber())) {
            throw new IllegalArgumentException("이미 존재하는 학번입니다.");
        }

        // UserEntity 생성 및 DTO 필드 매핑
        User entity = new User();
        entity.setStudentNumber(dto.getStudentNumber());
        entity.setName(dto.getName());
        entity.setGender(dto.getGender());
        entity.setEmail(dto.getEmail());
        entity.setMobilePhone(dto.getMobilePhone());
        entity.setZipCode(dto.getZipCode());
        entity.setAddress(dto.getAddress());
        entity.setDetailedAddress(dto.getDetailedAddress());

        // 역할 설정: DTO에서 제공된 값이 없으면 기본값 USER로 설정
        entity.setRole(dto.getRole() != null ? dto.getRole() : UserRoleType.USER);

        // Entity 저장
        userRepository.save(entity);
    }

    // 모든 사용자 조회
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    // 학번으로 사용자 조회
    public User getUserByStudentNumber(String studentNumber) {
        return userRepository.findById(studentNumber)
                .orElseThrow(() -> new IllegalArgumentException("사용자를 찾을 수 없습니다. 학번: " + studentNumber));
    }

    // 사용자 저장
    public User saveUser(User user) {
        return userRepository.save(user);
    }

    // 학번으로 사용자 삭제
    public void deleteUser(String studentNumber) {
        userRepository.deleteById(studentNumber);
    }
}
