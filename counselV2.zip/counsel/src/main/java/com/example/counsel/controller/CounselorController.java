package com.example.counsel.controller;

import com.example.counsel.entity.Counselor;
import com.example.counsel.service.CounselorService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/counselors") // 교직원을 위한 API 경로
public class CounselorController {

    private final CounselorService counselorService;

    public CounselorController(CounselorService counselorService) {
        this.counselorService = counselorService;
    }

    // 모든 교직원 조회
    @GetMapping
    public ResponseEntity<List<Counselor>> getAllCounselors() {
        return ResponseEntity.ok(counselorService.getAllCounselors());
    }

    // 특정 교직원 조회 (교직원 번호 기준)
    @GetMapping("/{empNumber}")
    public ResponseEntity<Counselor> getCounselorByEmpNumber(@PathVariable String empNumber) {
        return ResponseEntity.ok(counselorService.getCounselorByEmpNumber(empNumber));
    }

    // 교직원 등록
    @PostMapping
    public ResponseEntity<Counselor> createCounselor(@RequestBody Counselor counselor) {
        return ResponseEntity.ok(counselorService.saveCounselor(counselor));
    }

    // 교직원 수정 (교직원 번호 기준, 모든 필드 업데이트 가능)
    @PutMapping("/{empNumber}")
    public ResponseEntity<Counselor> updateCounselor(@PathVariable String empNumber, @RequestBody Counselor counselor) {
        return ResponseEntity.ok(counselorService.updateCounselor(empNumber, counselor));
    }

    // 교직원 삭제 (교직원 번호 기준)
    @DeleteMapping("/{empNumber}")
    public ResponseEntity<Void> deleteCounselor(@PathVariable String empNumber) {
        counselorService.deleteCounselor(empNumber);
        return ResponseEntity.noContent().build();
    }
}
