package com.example.counsel.service;

import com.example.counsel.entity.Counselor;
import com.example.counsel.repository.CounselorRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CounselorService {

    private final CounselorRepository counselorRepository;

    public CounselorService(CounselorRepository counselorRepository) {
        this.counselorRepository = counselorRepository;
    }

    // 모든 교직원 조회
    public List<Counselor> getAllCounselors() {
        return counselorRepository.findAll();
    }

    // 교직원 번호로 교직원 조회
    public Counselor getCounselorByEmpNumber(String empNumber) {
        return counselorRepository.findById(empNumber)
                .orElseThrow(() -> new IllegalArgumentException("교직원을 찾을 수 없습니다. 교직원번호: " + empNumber));
    }

    // 교직원 저장
    public Counselor saveCounselor(Counselor counselor) {
        return counselorRepository.save(counselor);
    }

    // 교직원 수정
    public Counselor updateCounselor(String empNumber, Counselor updatedCounselor) {
        // 기존 교직원 데이터 조회
        Counselor existingCounselor = counselorRepository.findById(empNumber)
                .orElseThrow(() -> new IllegalArgumentException("교직원을 찾을 수 없습니다. 교직원번호: " + empNumber));

        existingCounselor.setName(updatedCounselor.getName());
        existingCounselor.setEmail(updatedCounselor.getEmail());
        existingCounselor.setGender(updatedCounselor.getGender());
        existingCounselor.setMobilePhone(updatedCounselor.getMobilePhone());
        // 주소 변경
        existingCounselor.setAddress(updatedCounselor.getAddress());
        existingCounselor.setZipCode(updatedCounselor.getZipCode());
        existingCounselor.setDetailedAddress(updatedCounselor.getDetailedAddress());

        // 필요 시 다른 필드 추가
        // existingCounselor.setOtherField(updatedCounselor.getOtherField());

        return counselorRepository.save(existingCounselor);
    }

    // 교직원 삭제
    public void deleteCounselor(String empNumber) {
        counselorRepository.deleteById(empNumber);
    }
}
