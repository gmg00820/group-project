package com.example.counsel.entity;

import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;

@Entity
@Getter
@Setter
@Table(name = "EMP_NO") // 테이블 이름
public class Counselor {

    @Id
    @Column(name = "EMP_NO", length = 10, nullable = false)
    private String empNumber; // 학번 (Primary Key)

    @Column(name = "EMP_NM", length = 100, nullable = false)
    private String name; // 이름

    @Column(name = "GNDR", length = 10)
    private String gender; // 성별

    @Column(name = "EMAIL", length = 320)
    private String email; // 이메일

    @Column(name = "MBL_TELNO", length = 15)
    private String mobilePhone; // 휴대전화

    @Column(name = "ZIP", length = 5)
    private String zipCode; // 우편번호

    @Column(name = "ADDR", length = 200)
    private String address; // 주소

    @Column(name = "DADDR", length = 200)
    private String detailedAddress; // 상세주소
}
